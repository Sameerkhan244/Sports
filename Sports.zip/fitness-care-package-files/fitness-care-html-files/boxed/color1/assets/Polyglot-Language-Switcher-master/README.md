Polyglot-Language-Switcher
==========================

The &amp;quot;Polyglot&amp;quot; Language Switcher jQuery plugin allows you easily switch between the languages supported by your website. It was conceived as a drop-down menu with flag icons.